$(function (){
	$('.globe').on('click', function(){
		$('.icons').slideToggle();
	})
});